<?php
session_start();

$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] =  $_POST['password'];

include './auth.php';
$hotel_re = mysqli_query($dbhandle,"select * from hotel_admin where username = '".$_SESSION['username']."'  AND password = '".$_SESSION['password']."' " );
echo mysqli_error($dbhandle);

if(mysqli_num_rows($hotel_re) > 0)
{
header('Refresh: 0;url=dashboard_hotel.php');
}
else{

session_destroy();
header("location: hotel.php");
}
?>